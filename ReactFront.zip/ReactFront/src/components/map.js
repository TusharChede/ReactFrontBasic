// Map.js
import React from 'react';

// const Map = ({ center, zoom, profiles }) => {
//   return (
//     <div style={{ height: '400px', width: '100%' }}>
//       {/* Map component contents */}
//     </div>
//   );
// };

// export default Map;

// No need for the Map component in this scenario
