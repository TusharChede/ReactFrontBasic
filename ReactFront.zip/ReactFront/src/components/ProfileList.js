import React from 'react';
import ProfileDetails from './ProfileDetails';

const ProfileList = ({ profiles }) => {
  return (
    <div>
      {profiles.map(profile => (
        <ProfileDetails
          key={profile.id}
          profile={{
            id: profile.id,
            name: profile.name || "John Doe",
            photo: profile.photo || "https://example.com/profile.jpg",
            description: profile.description || "Lorem ipsum dolor sit amet, consectetur adipiscing elit.",
            address: profile.address || "123 Main St, City, Country",
            email: profile.email || "example@example.com",
            phone: profile.phone || "+1234567890"
          }}
        />
      ))}
    </div>
  );
};

export default ProfileList;
