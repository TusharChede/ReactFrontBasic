import React, { useState } from 'react';

const AdminPanel = ({ onAddProfile }) => {
  const [formData, setFormData] = useState({
    name: 'Jane Smith',
    photo: 'https://example.com/profile.jpg',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod tortor nec risus commodo, nec convallis metus commodo.',
    address: '456 Elm St, Town, Country'
  });

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = e => {
    e.preventDefault();
    // Validate form data
    if (!formData.name || !formData.photo || !formData.description || !formData.address) {
      alert('Please fill in all fields');
      return;
    }
    // Call the onAddProfile function passed as prop
    onAddProfile(formData);
    // Clear form fields after submission
    setFormData({ name: '', photo: '', description: '', address: '' });
  };

  return (
    <div>
      <h2>Admin Panel</h2>
      <form onSubmit={handleSubmit}>
        <label>Name:</label>
        <input type="text" name="name" value={formData.name} onChange={handleChange} />
        <label>Photo URL:</label>
        <input type="text" name="photo" value={formData.photo} onChange={handleChange} />
        <label>Description:</label>
        <textarea name="description" value={formData.description} onChange={handleChange}></textarea>
        <label>Address:</label>
        <input type="text" name="address" value={formData.address} onChange={handleChange} />
        <button type="submit">Add Profile</button>
      </form>
    </div>
  );
};

export default AdminPanel;
