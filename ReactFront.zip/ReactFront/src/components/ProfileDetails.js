import React from 'react';

const ProfileDetails = ({ profile }) => {
  return (
    <div>
      <h2>Profile Details</h2>
      <div>
        <img src={profile.photo} alt={profile.name} />
        <h3>{profile.name}</h3>
        <p>{profile.description}</p>
        <p>Location: {profile.address}</p>
        <p>Email: {profile.email}</p>
        <p>Phone: {profile.phone}</p>
        {/* Additional profile details can be added here */}
      </div>
    </div>
  );
};

export default ProfileDetails;
