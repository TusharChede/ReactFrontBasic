import React, { useState, useEffect } from 'react';
import ProfileList from './components/ProfileList';
import AdminPanel from './components/AdminPanel';
import ProfileDetails from './components/ProfileDetails';
import { getProfiles, addProfile } from './services/ProfileService';

function App() {
  const [profiles, setProfiles] = useState([]);
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [showAdminPanel, setShowAdminPanel] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const data = await getProfiles();
      setProfiles(data);
    };
    fetchData();
  }, []);

  const handleAddProfile = async (formData) => {
    try {
      const newProfile = await addProfile(formData);
      setProfiles([...profiles, newProfile]);
      alert('Profile added successfully!');
    } catch (error) {
      alert('Error adding profile. Please try again.');
      console.error(error);
    }
  };

  const handleProfileClick = (profile) => {
    setSelectedProfile(profile);
  };

  const handleShowAdminPanel = () => {
    setShowAdminPanel(true);
  };

  const handleCloseAdminPanel = () => {
    setShowAdminPanel(false);
  };

  return (
    <div>
      <h1>Profile Mapper</h1>
      <div style={{ display: 'flex' }}>
        <div style={{ flex: 1 }}>
          <ProfileList profiles={profiles} onProfileClick={handleProfileClick} />
          <button onClick={handleShowAdminPanel}>Add Profile</button>
        </div>
        <div style={{ flex: 2 }}>
          {selectedProfile ? (
            <ProfileDetails profile={selectedProfile} />
          ) : (
            <p>Please select a profile</p>
          )}
        </div>
      </div>
      {showAdminPanel && (
        <AdminPanel onClose={handleCloseAdminPanel} onAddProfile={handleAddProfile} />
      )}
    </div>
  );
}

export default App;
