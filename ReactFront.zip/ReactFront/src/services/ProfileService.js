const profiles = [
  {
    id: 1,
    name: 'John Doe',
    photo: 'https://example.com/john-doe.jpg',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    address: 'New York, USA',
    lat: 40.7128,
    lng: -74.006
  },
  {
    id: 2,
    name: 'Jane Smith',
    photo: 'https://example.com/jane-smith.jpg',
    description: 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.',
    address: 'Los Angeles, USA',
    lat: 34.0522,
    lng: -118.2437
  },
  // Add more sample profiles here
];

export const getProfiles = () => {
  // Simulate fetching profiles from an API or database
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(profiles);
    }, 1000); // Simulate 1 second delay
  });
};

export const addProfile = (profile) => {
  // Simulate adding a new profile to the list
  profile.id = profiles.length + 1;
  profiles.push(profile);
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(profile);
    }, 500); // Simulate 0.5 second delay
  });
};

// You can add more functions here for editing and deleting profiles if needed
